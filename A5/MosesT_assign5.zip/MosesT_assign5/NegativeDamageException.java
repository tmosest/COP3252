
public class NegativeDamageException extends Exception
{
  public NegativeDamageException(String message)
  {
    super(message);
  }
}
