public interface TicTacToeView {
  void start();
}
